
package Clases;

/**
 *
 * @author isard
 */
public class ActividadData {
    public int pasos;
    public double calorias;
    public double distancia;
}

