
package Clases;


public class ProgresoDiaData {
    public String fecha;
    public int pasos;
    public double calorias;
    public double distancia;
    public double peso;
}
