package com.mycompany.tfg; // Asegúrate de que el paquete sea el correcto

public class MainApp {

    public static void main(String[] args) {
        // Esto es boilerplate para el look and feel de Swing, déjalo tal cual
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        // Aquí es donde sucede la magia:
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                // PASO 1: Crea la instancia del Gerente General (Principal)
                // Es importante que Principal ya tenga su FitbitService inicializado aquí.
                Principal principalApp = new Principal(); // Llama al constructor de Principal.java

                // PASO 2: Crea la primera ventana que se mostrará (LogeoIniciarSesion)
                // y le PASA la instancia del Gerente General (principalApp).
                LogeoIniciarSesion loginFrame = new LogeoIniciarSesion(principalApp); 
                loginFrame.setLocationRelativeTo(null); // Centra la ventana
                loginFrame.setVisible(true); // La hace visible
            }
        });
    }
}