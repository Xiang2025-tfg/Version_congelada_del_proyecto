
package com.mycompany.tfg.data;

/**
 *
 * @author isard
 */
public class ActividadData {
    public int pasos;
    public double calorias;
    public double distancia;
}

