package com.mycompany.tfg.database;

import com.mycompany.tfg.data.ProgresoDiaData;
import com.mysql.cj.jdbc.MysqlDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;

public class Database {

    // Se mantiene como static para el patrón Singleton de conexión
    private static Connection connection;
    private static MysqlDataSource dataSource;

    /**
     * Crea una nueva conexión a la base de datos MySQL.
     * @return Una nueva instancia de Connection.
     * @throws SQLException Si ocurre un error al establecer la conexión.
     */
    public static Connection createConnection() throws SQLException {
        dataSource = new MysqlDataSource();
        dataSource.setUrl("jdbc:mysql://localhost:3306/gimnasio?useSSL=false&serverTimezone=UTC"); // Añadido parámetros para evitar warnings
        dataSource.setUser("root");
        dataSource.setPassword("");
        Connection newConnection = dataSource.getConnection();
        newConnection.setAutoCommit(true); // Se usa auto-commit por defecto para la mayoría de las operaciones
        System.out.println("Conexión a la base de datos establecida.");
        return newConnection;
    }

    /**
     * Obtiene una instancia de la conexión a la base de datos.
     * Si la conexión no existe o está cerrada, intenta crear una nueva.
     * Implementa un patrón Singleton para la conexión.
     * @return La instancia de Connection.
     * @throws SQLException Si ocurre un error al obtener o crear la conexión.
     */
    public static Connection getInstance() throws SQLException {
        // Verifica si la conexión es nula o si está cerrada/inválida
        if (connection == null || connection.isClosed() || !connection.isValid(5)) { // isValid(timeout) para verificar si sigue activa
            System.out.println("Re-creando conexión a la base de datos...");
            connection = createConnection();
        }
        return connection;
    }

    /**
     * Cierra la conexión a la base de datos si está abierta.
     * Es crucial llamar a este método al finalizar la aplicación.
     * @throws SQLException Si ocurre un error al cerrar la conexión.
     */
    public static void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
            connection = null;
            System.out.println("Conexión a la base de datos cerrada.");
        }
    }

    /**
     * Guarda un nuevo usuario en la tabla 'usuarios'.
     * @param dni DNI del usuario.
     * @param nombre Nombre del usuario.
     * @param apellido Apellido del usuario.
     * @param edad Edad del usuario.
     * @param genero Género del usuario.
     * @param objetivoSalud Objetivo de salud del usuario.
     * @param nivelActividad Nivel de actividad del usuario.
     * @param contrasena Contraseña del usuario.
     * @throws SQLException Si ocurre un error de SQL.
     */
    public static void guardarUsuario(String dni, String nombre, String apellido, int edad, String genero, String objetivoSalud, String nivelActividad, String contrasena) throws SQLException {
        String query = "INSERT INTO usuarios (dni, nombre, apellido, edad, genero, objetivo_salud, nivel_actividad, contraseña) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getInstance(); // Usar try-with-resources para asegurar cierre de stmt
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, dni);
            stmt.setString(2, nombre);
            stmt.setString(3, apellido);
            stmt.setInt(4, edad);
            stmt.setString(5, genero);
            stmt.setString(6, objetivoSalud);
            stmt.setString(7, nivelActividad);
            stmt.setString(8, contrasena);

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(null, "Usuario insertado correctamente");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo insertar el usuario.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al insertar usuario: " + e.getMessage(), "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            throw e;
        }
    }

    /**
     * Verifica las credenciales de un usuario.
     * @param dni DNI del usuario.
     * @param contrasena Contraseña del usuario.
     * @return El nombre del usuario si las credenciales son válidas, null en caso contrario.
     * @throws SQLException Si ocurre un error de SQL.
     */
    public static String verificarUsuario(String dni, String contrasena) throws SQLException {
        String nombreUsuario = null;
        String query = "SELECT nombre FROM usuarios WHERE dni = ? AND contraseña = ?";
        try (Connection conn = getInstance();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, dni);
            stmt.setString(2, contrasena);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    nombreUsuario = rs.getString("nombre");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al verificar usuario: " + e.getMessage(), "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            throw e;
        }
        return nombreUsuario;
    }

    /**
     * Comprueba si un usuario con el DNI especificado ya existe en la base de datos.
     * @param dni DNI a comprobar.
     * @return true si el usuario existe, false en caso contrario.
     */
    public static boolean usuarioExiste(String dni) {
        boolean existe = false;
        String query = "SELECT 1 FROM usuarios WHERE dni = ?";
        try (Connection conn = getInstance();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, dni);
            try (ResultSet rs = stmt.executeQuery()) {
                existe = rs.next();
            }
        } catch (SQLException e) {
            System.err.println("Error comprobando usuario: " + e.getMessage());
            // No se lanza la excepción, solo se loguea, ya que es una comprobación de existencia.
        }
        return existe;
    }

    /**
     * Obtiene todos los datos de un usuario por su DNI.
     * @param dni DNI del usuario.
     * @return Un ResultSet con los datos del usuario. Es responsabilidad del llamador cerrar este ResultSet.
     * @throws SQLException Si ocurre un error de SQL.
     */
    public static ResultSet obtenerDatosUsuario(String dni) throws SQLException {
        Connection conn = getInstance(); // No usamos try-with-resources aquí para que el ResultSet sea manejado por el llamador
        String sql = "SELECT * FROM usuarios WHERE dni = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, dni);
        return stmt.executeQuery();
    }

    /**
     * Actualiza los datos de un usuario existente.
     * @param dni DNI del usuario a actualizar.
     * @param nombre Nuevo nombre.
     * @param apellidos Nuevos apellidos.
     * @param edad Nueva edad.
     * @param genero Nuevo género.
     * @param objetivo Nuevo objetivo de salud.
     * @param actividad Nuevo nivel de actividad.
     * @param password Nueva contraseña.
     * @throws SQLException Si ocurre un error de SQL.
     */
    public static void actualizarUsuario(String dni, String nombre, String apellidos, int edad,
                                         String genero, String objetivo, String actividad, String password) throws SQLException {
        String sql = "UPDATE usuarios SET nombre=?, apellido=?, edad=?, genero=?, objetivo_salud=?, nivel_actividad=?, contraseña=? WHERE dni=?";
        try (Connection conn = getInstance();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, apellidos);
            stmt.setInt(3, edad);
            stmt.setString(4, genero);
            stmt.setString(5, objetivo);
            stmt.setString(6, actividad);
            stmt.setString(7, password);
            stmt.setString(8, dni);

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(null, "Datos de usuario actualizados correctamente.");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró el usuario para actualizar o no hubo cambios.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar usuario: " + e.getMessage(), "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            throw e;
        }
    }

    /**
     * Inserta o actualiza un registro de progreso completo en la tabla 'progreso'.
     * NO incluye frecuencia_cardiaca.
     * Si ya existe un registro para el mismo DNI y fecha, lo actualiza.
     * Si no existe, inserta uno nuevo.
     * Se manejan valores nulos o por defecto para campos no disponibles (-1 para int, -1.0 para double)
     * que se convierten a NULL en la base de datos si son estos valores.
     * @param dniUsuario DNI del usuario.
     * @param fecha Fecha del registro.
     * @param pasos Pasos registrados (use -1 si no hay datos).
     * @param calorias Calorías quemadas (use -1.0 si no hay datos).
     * @param distancia Distancia recorrida (use -1.0 si no hay datos).
     * @param peso Peso registrado (use -1.0 si no hay datos).
     * @throws SQLException Si ocurre un error de SQL.
     */
    public static void insertarOActualizarProgreso(String dniUsuario, LocalDate fecha,
                                                    int pasos, double calorias, double distancia, double peso) throws SQLException {

        String formattedDate = fecha.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        String selectSql = "SELECT id FROM progreso WHERE usuario_dni = ? AND fecha = ?";
        String updateSql = "UPDATE progreso SET pasos = ?, calorias = ?, distancia = ?, peso = ? WHERE id = ?";
        String insertSql = "INSERT INTO progreso (usuario_dni, fecha, pasos, calorias, distancia, peso) VALUES (?, ?, ?, ?, ?, ?)";

        Connection conn = null; // Declarar aquí para el bloque finally externo
        try {
            conn = getInstance();
            conn.setAutoCommit(false); // Iniciar transacción

            int existingId = -1;
            try (PreparedStatement selectPstmt = conn.prepareStatement(selectSql)) {
                selectPstmt.setString(1, dniUsuario);
                selectPstmt.setString(2, formattedDate);
                try (ResultSet rs = selectPstmt.executeQuery()) {
                    if (rs.next()) {
                        existingId = rs.getInt("id");
                    }
                }
            }

            if (existingId != -1) {
                // Actualizar
                try (PreparedStatement updatePstmt = conn.prepareStatement(updateSql)) {
                    if (pasos != -1) updatePstmt.setInt(1, pasos); else updatePstmt.setNull(1, java.sql.Types.INTEGER);
                    if (calorias != -1.0) updatePstmt.setDouble(2, calorias); else updatePstmt.setNull(2, java.sql.Types.DECIMAL);
                    if (distancia != -1.0) updatePstmt.setDouble(3, distancia); else updatePstmt.setNull(3, java.sql.Types.DECIMAL);
                    if (peso != -1.0) updatePstmt.setDouble(4, peso); else updatePstmt.setNull(4, java.sql.Types.DECIMAL);
                    updatePstmt.setInt(5, existingId);

                    int affectedRows = updatePstmt.executeUpdate();
                    if (affectedRows > 0) {
                        System.out.println("Progreso actualizado para " + dniUsuario + " en la fecha " + fecha + " (ID: " + existingId + ")");
                    } else {
                        System.out.println("Fallo al actualizar progreso para " + dniUsuario + " en la fecha " + fecha + " (ID: " + existingId + ")");
                    }
                }
            } else {
                // Insertar
                try (PreparedStatement insertPstmt = conn.prepareStatement(insertSql)) {
                    insertPstmt.setString(1, dniUsuario);
                    insertPstmt.setString(2, formattedDate);
                    if (pasos != -1) insertPstmt.setInt(3, pasos); else insertPstmt.setNull(3, java.sql.Types.INTEGER);
                    if (calorias != -1.0) insertPstmt.setDouble(4, calorias); else insertPstmt.setNull(4, java.sql.Types.DECIMAL);
                    if (distancia != -1.0) insertPstmt.setDouble(5, distancia); else insertPstmt.setNull(5, java.sql.Types.DECIMAL);
                    if (peso != -1.0) insertPstmt.setDouble(6, peso); else insertPstmt.setNull(6, java.sql.Types.DECIMAL);

                    int affectedRows = insertPstmt.executeUpdate();
                    if (affectedRows > 0) {
                        System.out.println("Nuevo registro de progreso insertado para " + dniUsuario + " en la fecha " + fecha);
                    } else {
                        System.out.println("Fallo al insertar nuevo registro de progreso para " + dniUsuario + " en la fecha " + fecha);
                    }
                }
            }
            conn.commit(); // Confirmar transacción si todo fue bien
        } catch (SQLException e) {
            System.err.println("Error SQL al insertar/actualizar progreso para " + dniUsuario + ": " + e.getMessage());
            e.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback(); // Deshacer transacción si algo falla
                    System.err.println("Rollback de la transacción completado.");
                } catch (SQLException ex) {
                    System.err.println("Error durante el rollback: " + ex.getMessage());
                }
            }
            throw e; // Relanzar la excepción para que el llamador la maneje
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true); // Restaurar auto-commit a true al finalizar la transacción
            }
        }
    }

    /**
     * Obtiene el historial de progreso de un usuario desde la base de datos para un rango de fechas.
     * NO incluye frecuencia_cardiaca.
     * @param dniUsuario DNI del usuario.
     * @param fechaInicio Fecha de inicio del rango (yyyy-MM-dd).
     * @param fechaFin Fecha de fin del rango (yyyy-MM-dd).
     * @return Una lista de objetos ProgresoDiaData.
     * @throws SQLException Si ocurre un error de SQL.
     */
    public static List<ProgresoDiaData> obtenerProgresoPorDNI(String dniUsuario, String fechaInicio, String fechaFin) throws SQLException {
        List<ProgresoDiaData> progresoList = new ArrayList<>();
        String sql = "SELECT fecha, pasos, calorias, distancia, peso FROM progreso WHERE usuario_dni = ? AND fecha BETWEEN ? AND ? ORDER BY fecha ASC";

        try (Connection conn = getInstance();
             PreparedStatement pstmt = conn.prepareStatement(sql);) {

            pstmt.setString(1, dniUsuario);
            pstmt.setString(2, fechaInicio);
            pstmt.setString(3, fechaFin);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    ProgresoDiaData diaData = new ProgresoDiaData();
                    diaData.fecha = rs.getString("fecha");

                    // Obtener valores y manejar NULLs explícitamente
                    diaData.pasos = rs.getInt("pasos");
                    if (rs.wasNull()) diaData.pasos = -1; // -1 indica "no hay datos"

                    diaData.calorias = rs.getDouble("calorias");
                    if (rs.wasNull()) diaData.calorias = -1.0;

                    diaData.distancia = rs.getDouble("distancia");
                    if (rs.wasNull()) diaData.distancia = -1.0;

                    diaData.peso = rs.getDouble("peso");
                    if (rs.wasNull()) diaData.peso = -1.0;

                    progresoList.add(diaData);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener progreso desde DB para DNI " + dniUsuario + ": " + e.getMessage());
            throw e;
        }
        return progresoList;
    }

    
    public static Map<String, Object> obtenerProgresoPorFecha(String dniUsuario, LocalDate fecha) throws SQLException {
        Map<String, Object> datosProgreso = new HashMap<>();
        String fechaStr = fecha.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        // Selecciona todas las columnas relevantes de 'progreso': pasos, calorias, distancia, peso.
        String sql = "SELECT pasos, calorias, distancia, peso FROM progreso WHERE usuario_dni = ? AND fecha = ? ORDER BY id DESC LIMIT 1";

        try (Connection conn = getInstance();
             PreparedStatement pst = conn.prepareStatement(sql);) {

            pst.setString(1, dniUsuario);
            pst.setString(2, fechaStr);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    int pasos = rs.getInt("pasos");
                    datosProgreso.put("pasos", rs.wasNull() ? null : pasos);

                    double calorias = rs.getDouble("calorias");
                    datosProgreso.put("calorias", rs.wasNull() ? null : calorias);

                    double distancia = rs.getDouble("distancia");
                    datosProgreso.put("distancia", rs.wasNull() ? null : distancia);

                    double peso = rs.getDouble("peso");
                    datosProgreso.put("peso", rs.wasNull() ? null : peso);
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error al obtener progreso completo por fecha desde DB para DNI " + dniUsuario + ": " + ex.getMessage());
            throw ex;
        }
        return datosProgreso;
    }
}