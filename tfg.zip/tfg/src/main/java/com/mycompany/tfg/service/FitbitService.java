package com.mycompany.tfg.service;

// Importaciones necesarias para la comunicación HTTP y JSON
import com.mycompany.tfg.data.ActividadData;
import com.mycompany.tfg.data.ProgresoDiaData;
import com.mycompany.tfg.data.SaludData;
import org.json.JSONArray;
import org.json.JSONObject;
import java.awt.Desktop; // Parece que no se usa en este código, pero lo mantengo si lo usas en otro lugar.
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI; // Parece que no se usa en este código, pero lo mantengo si lo usas en otro lugar.
import java.net.URL;
import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class FitbitService {

    private static final String CLIENT_ID = "23QJSQ";
    private static final String CLIENT_SECRET = "a6a50ff1a578792593dc66535d4b8040";
    private static final String REDIRECT_URI = "http://localhost:8080/fitbit_callback";

    private static final String SCOPE = "activity weight profile"; 

    private String accessToken;
    private String fitbitUserId; // Variable para almacenar el ID de usuario de Fitbit

    /**
     * Constructor de la clase FitbitService.
     * En este modo simplificado, FitbitService no gestiona la persistencia de tokens
     * ni el refresco. El token se mantiene en memoria solo para la sesión actual.
     */
    public FitbitService() {
        // No hay lógica de carga de tokens al instanciar en este modo.
        // Los tokens serán obtenidos y mantenidos en memoria solo durante la sesión actual.
    }

    /**
     * Devuelve la URL de autorización de Fitbit.
     * Esta URL se usará para redirigir al usuario al navegador para que autorice la aplicación.
     * @return La URL de autorización.
     */
    public String getAuthorizationUrl() {
        try {
            return "https://www.fitbit.com/oauth2/authorize?" +
                    "response_type=code" +
                    "&client_id=" + CLIENT_ID +
                    "&redirect_uri=" + URLEncoder.encode(REDIRECT_URI, StandardCharsets.UTF_8.toString()) +
                    "&scope=" + URLEncoder.encode(SCOPE, StandardCharsets.UTF_8.toString()) +
                    "&expires_in=604800"; // Tiempo de expiración del token de acceso (ej: 1 semana)
        } catch (IOException e) {
            // Esto no debería ocurrir con StandardCharsets.UTF_8
            throw new RuntimeException("Error al codificar la URI de redirección", e);
        }
    }

    /**
     * Intercambia el código de autorización obtenido de Fitbit por un token de acceso.
     * Este token se almacena en memoria en esta instancia de FitbitService.
     * No se guardan ni se usan tokens de refresco en este modelo.
     * @param code El código de autorización.
     * @throws IOException Si la llamada al API de tokens falla.
     */
    public void exchangeCodeForTokens(String code) throws IOException {
        URL tokenURL = new URL("https://api.fitbit.com/oauth2/token");
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) tokenURL.openConnection();
            conn.setRequestMethod("POST");

            String basicAuth = Base64.getEncoder().encodeToString((CLIENT_ID + ":" + CLIENT_SECRET).getBytes());
            conn.setRequestProperty("Authorization", "Basic " + basicAuth);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setDoOutput(true);

            String params = "client_id=" + CLIENT_ID +
                            "&grant_type=authorization_code" +
                            "&redirect_uri=" + URLEncoder.encode(REDIRECT_URI, StandardCharsets.UTF_8.toString()) +
                            "&code=" + URLEncoder.encode(code, StandardCharsets.UTF_8.toString());

            try (OutputStream os = conn.getOutputStream()) {
                os.write(params.getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = conn.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                String errorMsg = "Desconocido";
                try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(conn.getErrorStream()))) {
                    StringBuilder errorResponse = new StringBuilder();
                    String line;
                    while ((line = errorReader.readLine()) != null) {
                        errorResponse.append(line);
                    }
                    errorMsg = errorResponse.toString();
                } catch (Exception e) {
                    System.err.println("Error al leer stream de error: " + e.getMessage());
                }
                throw new IOException("Error al obtener tokens (" + responseCode + "): " + errorMsg);
            }

            try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String input;
                while ((input = in.readLine()) != null) {
                    response.append(input);
                }
                JSONObject json = new JSONObject(response.toString());
                this.accessToken = json.getString("access_token");
                this.fitbitUserId = json.getString("user_id"); // Almacenar el ID de usuario de Fitbit

                System.out.println("Access Token y Fitbit User ID obtenidos con éxito (en memoria).");
            }

        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    /**
     * Verifica si el token de acceso actual es válido (no nulo y no vacío).
     * En este modo simplificado, no se rastrea la expiración del token.
     * Si el token es inválido o expira, las llamadas a la API fallarán y el usuario deberá re-autenticarse.
     * @return true si el token existe en memoria, false en caso contrario.
     */
    public boolean hasValidAccessToken() {
        return accessToken != null && !accessToken.trim().isEmpty();
    }

    /**
     * Realiza una solicitud GET a la API de Fitbit con el token de acceso.
     * Si el token no es válido o la API devuelve 401, se lanzará una excepción.
     * @param endpoint La URL completa del endpoint de la API de Fitbit.
     * @return La respuesta de la API como una cadena JSON.
     * @throws IOException Si hay un error de red o la API devuelve un código de error (incluido 401 Unauthorized).
     */
    private String makeFitbitApiRequest(String endpoint) throws IOException {
        if (!hasValidAccessToken()) {
            throw new IOException("No hay token de acceso válido. Por favor, conéctate con Fitbit de nuevo.");
        }
        
        if (this.fitbitUserId == null || this.fitbitUserId.isEmpty()) {
             throw new IOException("No se ha obtenido el Fitbit User ID. Re-autentica con Fitbit.");
        }

        // Reemplazar el marcador de posición con el ID de usuario real de Fitbit
        String finalEndpoint = endpoint.replace("{fitbit_user_id}", this.fitbitUserId);


        HttpURLConnection conn = null;
        try {
            URL url = new URL(finalEndpoint);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);

            int responseCode = conn.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                String errorMsg = "Desconocido";
                try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(conn.getErrorStream()))) {
                    StringBuilder errorResponse = new StringBuilder();
                    String line;
                    while ((line = errorReader.readLine()) != null) {
                        errorResponse.append(line);
                    }
                    errorMsg = errorResponse.toString();
                } catch (Exception e) {
                    System.err.println("Error al leer stream de error para endpoint " + finalEndpoint + ": " + e.getMessage());
                }
                if (responseCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
                    // Limpiar el token y el ID si es 401 para forzar la re-autenticación
                    this.accessToken = null;
                    this.fitbitUserId = null;
                    throw new IOException("Error de API Fitbit (401 Unauthorized) en " + finalEndpoint + ": " + errorMsg +
                                          ". El token ha expirado o es inválido. Por favor, re-autentica con Fitbit.");
                } else {
                    throw new IOException("Error de API Fitbit (" + finalEndpoint + "): " + responseCode + " - " + errorMsg);
                }
            }

            try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String input;
                while ((input = in.readLine()) != null) {
                    response.append(input);
                }
                return response.toString();
            }
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    /**
     * Obtiene los datos de actividad diaria de Fitbit para una fecha específica.
     * @param fecha La fecha en formato "yyyy-MM-dd".
     * @return Un objeto ActividadData con los pasos, calorías y distancia.
     * @throws IOException Si falla la llamada a la API o el parseo JSON.
     */
    public ActividadData getActividadData(String fecha) throws IOException {
        // Usar {fitbit_user_id} como marcador de posición que makeFitbitApiRequest reemplazará
        String response = makeFitbitApiRequest("https://api.fitbit.com/1/user/{fitbit_user_id}/activities/date/" + fecha + ".json");
        JSONObject json = new JSONObject(response);

        JSONObject summary = json.optJSONObject("summary");

        ActividadData data = new ActividadData();
        if (summary != null) {
            data.pasos = summary.optInt("steps", 0);
            data.calorias = summary.optInt("caloriesOut", 0);
            
            JSONArray distances = summary.optJSONArray("distances");
            data.distancia = 0.0;
            if (distances != null) {
                for (int i = 0; i < distances.length(); i++) {
                    JSONObject distObj = distances.getJSONObject(i);
                    if ("total".equals(distObj.optString("activity"))) {
                        data.distancia = distObj.optDouble("distance", 0.0);
                        break;
                    }
                }
            }
        } else {
            System.out.println("No se encontró summary de actividad para la fecha " + fecha + ". Retornando datos vacíos.");
        }
        return data;
    }

    /**
     * Obtiene los datos de peso de Fitbit para una fecha específica.
     * @param fecha La fecha en formato "yyyy-MM-dd".
     * @return Un objeto SaludData con el peso.
     * @throws IOException Si falla la llamada a la API o el parseo JSON.
     */
    public SaludData getPesoData(String fecha) throws IOException {
        // Usar {fitbit_user_id} como marcador de posición que makeFitbitApiRequest reemplazará
        String response = makeFitbitApiRequest("https://api.fitbit.com/1/user/{fitbit_user_id}/body/log/weight/date/" + fecha + ".json");
        JSONObject json = new JSONObject(response);
        SaludData data = new SaludData();
        JSONArray weights = json.optJSONArray("weight");
        if (weights != null && weights.length() > 0) {
            data.peso = weights.getJSONObject(0).optDouble("weight", 0.0);
        } else {
            data.peso = 0.0;
            System.out.println("No se encontró registro de peso para la fecha " + fecha + ". Retornando 0.0.");
        }
        return data;
    }

    /**
     * Combina la obtención de datos de actividad y peso de Fitbit para una fecha dada.
     * Este método SÓLO OBTIENE los datos de la API de Fitbit, NO los guarda en la base de datos.
     * @param fecha La fecha en formato "yyyy-MM-dd".
     * @return Un objeto ProgresoDiaData con los datos combinados.
     * @throws IOException Si falla la llamada a la API o el parseo JSON.
     */
    public ProgresoDiaData getProgresoCompleto(String fecha) throws IOException {
        ActividadData actividad = getActividadData(fecha);
        SaludData salud = getPesoData(fecha);

        ProgresoDiaData progresoCompleto = new ProgresoDiaData();
        progresoCompleto.fecha = fecha;
        progresoCompleto.pasos = actividad.pasos;
        progresoCompleto.calorias = actividad.calorias;
        progresoCompleto.distancia = actividad.distancia;
        progresoCompleto.peso = salud.peso;

        return progresoCompleto;
    }
    
    // Getter para el access token (útil para verificar si está presente desde la UI)
    public String getAccessToken() {
        return accessToken;
    }

    // Nuevo Getter para el Fitbit User ID
    public String getFitbitUserId() {
        return fitbitUserId;
    }
}