/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.tfg.ui;

// Importaciones necesarias para la comunicación HTTP y JSON (ya las tendrás en FitbitService o necesitarás añadirlas si faltan)
// Asegúrate de que estas clases de 'Clases' existan en tu proyecto en el paquete 'Clases'
import com.mycompany.tfg.database.Database;
import com.mycompany.tfg.data.ActividadData;
import com.mycompany.tfg.data.ProgresoDiaData;
import com.mycompany.tfg.data.SaludData;

import com.mycompany.tfg.service.FitbitService; 

import java.awt.Desktop; // Para abrir el navegador
import java.io.BufferedReader; // No es directamente necesario aquí si FitbitService maneja las peticiones HTTP
import java.io.InputStreamReader; // No es directamente necesario aquí
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI; // Para la URL de autorización
import java.net.URL; // No es directamente necesario aquí
import java.net.URLEncoder; // No es directamente necesario aquí
import java.net.HttpURLConnection; // No es directamente necesario aquí
import java.nio.charset.StandardCharsets;
import java.util.Base64; // No es directamente necesario aquí
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane; // Para mostrar mensajes al usuario

// Imports para el servidor HTTP (Son necesarios y están bien)
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.net.InetSocketAddress;
import java.sql.SQLException; // Importa SQLException si tu clase Database la lanza
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture; // Para el callback del servidor HTTP

/**
 *
 * @author isard
 */
public class Principal {

    // Instancia de FitbitService que será utilizada por toda la aplicación
    private FitbitService fitbitService;
    // Variable para almacenar el DNI del usuario que se ha logueado
    // Necesario para guardar los datos de Fitbit en la base de datos asociada a ese DNI
    private String dniUsuarioActual; // Este DNI se establecerá cuando el usuario inicie sesión

    // Constructor de la clase Principal
    public Principal() {
        // Inicializa FitbitService cuando se crea una instancia de Principal
        // Asegúrate de que FitbitService tenga un constructor adecuado que reciba CLIENT_ID, SECRET y REDIRECT_URI
        // O que los lea de un archivo de configuración si es más complejo.
        // Por ejemplo, si FitbitService los tiene como constantes, el constructor sin argumentos es suficiente.
        this.fitbitService = new FitbitService(); // Asumiendo que FitbitService se inicializa con sus constantes internas
        
        // Inicia el servidor HTTP para el callback de Fitbit
        // Es importante que el servidor empiece a escuchar ANTES de que el usuario intente conectarse con Fitbit
        iniciarServidorCallback(); 
    }

    // Método getter para permitir que otras clases (ventanas) obtengan la instancia de FitbitService
    public FitbitService getFitbitService() {
        return fitbitService;
    }

    // Método setter para establecer el DNI del usuario actualmente logueado
    // Las ventanas de login/registro deberían llamar a este método cuando un usuario inicia sesión
    public void setDniUsuarioActual(String dni) {
        this.dniUsuarioActual = dni;
    }

    // Método getter para obtener el DNI del usuario actual
    public String getDniUsuarioActual() {
        return dniUsuarioActual;
    }

    // El método main es el punto de entrada de la aplicación
    public static void main(String[] args) {
        // Primero, se crea la instancia de nuestro "Controlador Central" o "Gestor" (Principal)
        Principal app = new Principal(); // Esto también inicializará el FitbitService y el servidor HTTP

        // Luego, se lanza la interfaz de usuario en el hilo de eventos de Swing.
        // Se pasa la instancia de 'app' (Principal) a la primera ventana que se mostrará.
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                // Si la primera ventana es InicioSesion (la que te muestra opciones de iniciar/crear cuenta)
                // y LogeoIniciarSesion es una ventana secundaria de login,
                // entonces pasamos 'app' a InicioSesion.
                InicioSesion ventanaInicial = new InicioSesion(app); // PASAMOS LA INSTANCIA DE Principal
                ventanaInicial.setLocationRelativeTo(null); // Centrar la ventana
                ventanaInicial.setVisible(true);
            }
        });
    }

    /**
     * Inicia el servidor HTTP para manejar el callback de Fitbit.
     * Este método debe ser llamado una vez al inicio de la aplicación.
     */
    public void iniciarServidorCallback() {
        try {
            // Se crea el servidor en el puerto 8080.
            HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
            System.out.println("Servidor HTTP iniciado en el puerto 8080 para callback de Fitbit.");

            // Se define el contexto para la URL de redirección configurada en Fitbit
            server.createContext("/fitbit_callback", new HttpHandler() {
                @Override
                public void handle(HttpExchange exchange) throws IOException {
                    // Contenido HTML básico para la respuesta al navegador
                    String responseHtml = "<!DOCTYPE html><html><head><title>Fitbit Auth</title></head><body><h1>Procesando autorización de Fitbit...</h1><p>Puedes cerrar esta ventana.</p></body></html>";
                    String query = exchange.getRequestURI().getQuery();
                    Map<String, String> queryParams = parseQueryParams(query);

                    String code = queryParams.get("code");
                    String error = queryParams.get("error");

                    if (code != null) {
                        // Se ejecuta la lógica de intercambio de tokens y sincronización en un hilo separado
                        // para no bloquear el servidor HTTP (que está en su propio hilo) ni la UI.
                        CompletableFuture.runAsync(() -> {
                            try {
                                System.out.println("Código de autorización de Fitbit recibido: " + code);
                                fitbitService.exchangeCodeForTokens(code); // Intercambia el código por tokens

                                if (dniUsuarioActual != null && fitbitService.hasValidAccessToken()) {
                                    LocalDate fechaSincronizar = LocalDate.now();
                                    String fechaStr = fechaSincronizar.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

                                    // Obtener los datos de Fitbit para la fecha actual
                                    ProgresoDiaData datosFitbit = fitbitService.getProgresoCompleto(fechaStr);

                                    // Guardar o actualizar los datos en tu base de datos
                                    Database.insertarOActualizarProgreso(dniUsuarioActual, fechaSincronizar,
                                            datosFitbit.pasos, datosFitbit.calorias, datosFitbit.distancia, datosFitbit.peso);

                                    System.out.println("Sincronización con Fitbit y DB completada con éxito para DNI: " + dniUsuarioActual);
                                    // Actualiza la respuesta HTML para el usuario
                                    // Esta actualización se verá en el navegador, no en la app Swing.
                                    // Si quieres notificar a la UI de Swing, necesitarías un mecanismo más complejo
                                    // como un Listener o usar SwingUtilities.invokeLater.
                                } else {
                                    String msg = "Error: Autenticación Fitbit exitosa, pero no se pudo sincronizar con la DB (DNI de usuario no definido o token no válido).";
                                    System.err.println(msg);
                                }
                            } catch (IOException e) {
                                System.err.println("Error al procesar tokens o datos de Fitbit: " + e.getMessage());
                                e.printStackTrace();
                            } catch (SQLException e) {
                                System.err.println("Error de base de datos al guardar progreso de Fitbit: " + e.getMessage());
                                e.printStackTrace();
                            }
                        }); // Fin CompletableFuture.runAsync
                        
                    } else if (error != null) {
                        String msg = "Error de autorización de Fitbit: " + error;
                        System.err.println(msg);
                    } else {
                        String msg = "No se recibió código de autorización ni error de Fitbit.";
                        System.err.println(msg);
                    }

                    // Envía la respuesta HTML al navegador (esto se hace aquí inmediatamente
                    // porque la operación de Fitbit y DB es asíncrona)
                    exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF_8");
                    exchange.sendResponseHeaders(200, responseHtml.getBytes(StandardCharsets.UTF_8).length);
                    try (OutputStream os = exchange.getResponseBody()) {
                        os.write(responseHtml.getBytes(StandardCharsets.UTF_8));
                    }
                }
            });

            server.setExecutor(null); // Usa un executor por defecto para manejar las solicitudes entrantes
            server.start(); // Inicia el servidor en un hilo separado para no bloquear la UI

        } catch (IOException e) {
            String msg = "Error al iniciar el servidor HTTP para el callback de Fitbit en el puerto 8080. " +
                         "Asegúrate de que el puerto no esté en uso por otra aplicación y que tu firewall lo permita. " +
                         "Detalles: " + e.getMessage();
            System.err.println(msg);
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, msg, "Error de Servidor", JOptionPane.ERROR_MESSAGE);
            // Si el servidor no arranca, la funcionalidad de Fitbit no funcionará.
            // Considera si la aplicación debe salir o no.
        }
    }

    /**
     * Método auxiliar para parsear los parámetros de la URL de callback.
     * @param query La cadena de consulta de la URL.
     * @return Un mapa de parámetros (nombre -> valor).
     */
    private Map<String, String> parseQueryParams(String query) {
        Map<String, String> params = new HashMap<>();
        if (query != null && !query.isEmpty()) {
            String[] pairs = query.split("&");
            for (String pair : pairs) {
                int idx = pair.indexOf("=");
                if (idx > 0) {
                    try {
                        params.put(java.net.URLDecoder.decode(pair.substring(0, idx), StandardCharsets.UTF_8.toString()),
                                   java.net.URLDecoder.decode(pair.substring(idx + 1), StandardCharsets.UTF_8.toString()));
                    } catch (IOException e) { // IOException para URLDecoder (obsoleto con StandardCharsets)
                        System.err.println("Error de codificación al parsear query params: " + e.getMessage());
                    }
                }
            }
        }
        return params;
    }

    /**
     * Este método se encarga de iniciar el flujo de autenticación de Fitbit.
     * Debería ser llamado desde tu interfaz de usuario (ej. un botón "Conectar con Fitbit")
     * después de que el usuario haya iniciado sesión en tu aplicación.
     * @param dniUsuario El DNI del usuario actualmente logueado en tu aplicación.
     */
    public void iniciarAutenticacionFitbit(String dniUsuario) {
        this.dniUsuarioActual = dniUsuario; // Guarda el DNI para que el callback lo use al guardar en la DB
        String authUrl = fitbitService.getAuthorizationUrl();
        try {
            Desktop.getDesktop().browse(new URI(authUrl));
            System.out.println("Abriendo navegador para autorización de Fitbit...");
        } catch (IOException | java.net.URISyntaxException e) {
            System.err.println("Error al abrir el navegador para la autorización de Fitbit: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "No se pudo abrir el navegador para la autorización de Fitbit. Verifica la configuración.", "Error de Autenticación", JOptionPane.ERROR_MESSAGE);
        }
    }
}